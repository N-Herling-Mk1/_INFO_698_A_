/* ============================================================
   INFO 698 // CAPSTONE — splash.js
   ============================================================ */

(function () {
  'use strict';

  AresData.startClock('ts');

  AresData.load('meta.json').then(function (meta) {
    var s = meta.site || {};

    setText('splash-tagline', '— ' + (s.institution || '') + ' —');
    setText('splash-program', s.program || '');
    setText('stat-cycle',     s.cycle    || '');
    setText('stat-operator', (s.operator || '').toUpperCase());
    setText('hud-version',    s.version  || '');

    if (s.status) {
      var el = document.getElementById('stat-status');
      if (el) {
        el.innerHTML =
          '<span style="display:inline-block; width:6px; height:6px; ' +
          'background:var(--ares-lime); border-radius:50%; margin-right:6px;"></span>' +
          s.status;
      }
    }

    document.title = (s.course ? s.course + ' // ' : '') + (s.courseName || 'Capstone');

  }).catch(function (err) {
    console.warn('[splash] meta load failed — using HTML defaults:', err);
  });

  function setText(id, val) {
    var el = document.getElementById(id);
    if (el && val) el.textContent = val;
  }
})();
