/* ============================================================
   INFO 698 // CAPSTONE — nav.js
   Builds the radial menu from data/nodes.json
   ============================================================ */

(function () {
  'use strict';

  var CENTER_X = 340;
  var CENTER_Y = 340;
  var RADIUS   = 265;          // matches the middle SVG ring
  var NODE_SZ  = 110;          // .node width/height in CSS

  var radial   = document.getElementById('radial');
  var readout  = document.getElementById('readout');
  var spokes   = document.getElementById('radial-spokes');
  var hudCount = document.getElementById('hud-count');

  AresData.load('nodes.json').then(function (data) {
    var nodes = (data && data.nodes) || [];

    nodes.forEach(function (n) { buildNode(n); });
    if (hudCount) hudCount.textContent = nodes.length + ' NODES // 0 LOCKED';
  }).catch(function (err) {
    console.error('[nav] failed to load nodes.json:', err);
    if (readout) {
      readout.textContent = '[ ERR // NODE DATA UNAVAILABLE ]';
      readout.style.borderColor = '#ff3030';
      readout.style.color = '#ff3030';
    }
  });

  function buildNode(n) {
    var rad = (n.angle || 0) * Math.PI / 180;
    var x = CENTER_X + RADIUS * Math.cos(rad);
    var y = CENTER_Y + RADIUS * Math.sin(rad);

    // Convert SVG coords (0..680) to % of container so it scales responsively
    var leftPct = ((x - NODE_SZ / 2) / 680) * 100;
    var topPct  = ((y - NODE_SZ / 2) / 680) * 100;

    var a = document.createElement('a');
    a.className = 'node ares-frame';
    a.href = n.href || '#';
    if (n.external) {
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
    }
    a.style.left = leftPct + '%';
    a.style.top  = topPct  + '%';
    a.style.border = '1px solid ' + n.color + '66';
    a.style.color  = n.color;
    a.setAttribute('data-id', n.id);

    a.innerHTML =
      '<span class="ares-corner-bl" style="border-color:' + n.color + ';"></span>' +
      '<span class="ares-corner-br" style="border-color:' + n.color + ';"></span>' +
      '<i class="ti ' + n.icon + ' node-icon" aria-hidden="true"></i>' +
      '<span class="node-label">' + n.label + '</span>' +
      '<span class="node-id">' + n.id + '</span>';

    // Re-color the top corner brackets too (the ::before/::after are CSS-fixed lime;
    // we override inline via additional spans is overkill — just leave lime as accent).

    a.addEventListener('mouseenter', function () {
      a.style.borderColor = n.color;
      a.style.boxShadow = '0 0 0 1px ' + n.color + '40';
      if (readout) {
        readout.innerHTML =
          '<span style="color:' + n.color + ';">[ ' + n.id + ' ]</span> &nbsp;' +
          n.label.toUpperCase() + ' // ' + (n.sub || '').toUpperCase();
        readout.style.borderColor = n.color + '80';
        readout.style.color = n.color;
      }
    });

    a.addEventListener('mouseleave', function () {
      a.style.borderColor = n.color + '66';
      a.style.boxShadow = 'none';
      if (readout) {
        readout.textContent = '[ HOVER NODE // AWAITING INPUT ]';
        readout.style.borderColor = 'rgba(0, 217, 255, 0.3)';
        readout.style.color = 'var(--ares-muted)';
      }
    });

    radial.appendChild(a);

    // Add a faint spoke from inner ring out to the node
    if (spokes) {
      var ix = CENTER_X + 115 * Math.cos(rad);
      var iy = CENTER_Y + 115 * Math.sin(rad);
      var ox = CENTER_X + 200 * Math.cos(rad);
      var oy = CENTER_Y + 200 * Math.sin(rad);
      var line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
      line.setAttribute('x1', ix);
      line.setAttribute('y1', iy);
      line.setAttribute('x2', ox);
      line.setAttribute('y2', oy);
      spokes.appendChild(line);
    }
  }
})();
